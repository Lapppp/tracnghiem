<?php

namespace App\Enums\Products;

use BenSampo\Enum\Enum;

final class StarType extends Enum
{
    const NumberStart =  [1,2,3,4,5];
}
