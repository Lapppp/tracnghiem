<?php

namespace App\Http\Controllers\Frontend\Locations;
use App\Http\Controllers\FrontendController;
use Illuminate\Http\Request;

class ProvinceController extends FrontendController
{
    /**
     * @param  Request  $request
     */
    public function change(Request $request)
    {
        //
    }
}
