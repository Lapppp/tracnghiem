<?php

namespace App\Http\Controllers\Frontend\Test;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TestController extends Controller
{

    public function index( Request $request ){
        $details = [
            'title' => 'Mail from ItSolutionStuff.com',
            'body' => 'This is for testing email using smtp'
        ];

        \Mail::to('khanhnam99@gmail.com')->send(new \App\Mail\MyTestMail($details));

        dd("Email is Sent.");
    }
}
